import Stripe from 'stripe';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Méthode non autorisée' });

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://scoutreport.vercel.app';
  const { playerName, sport, reportData } = req.body;

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      mode: 'payment',
      success_url: `${baseUrl}/success.html?session_id={CHECKOUT_SESSION_ID}&player=${encodeURIComponent(playerName)}&sport=${encodeURIComponent(sport)}`,
      cancel_url: `${baseUrl}/index.html#generator`,
      metadata: {
        playerName,
        sport,
        reportSummary: reportData ? JSON.stringify(reportData).slice(0, 500) : '',
      },
      payment_intent_data: {
        description: `ScoutReport.ai — Rapport complet : ${playerName} (${sport})`,
      },
    });

    return res.status(200).json({ url: session.url, sessionId: session.id });
  } catch (error) {
    return res.status(500).json({ error: 'Erreur paiement', message: error.message });
  }
}
