export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Méthode non autorisée' });

  const { nom, age, poste, niveau, sport, tech, phys, tact, obs } = req.body;
  if (!nom || !age || !poste || !niveau || !sport) {
    return res.status(400).json({ error: 'Données manquantes' });
  }

  const prompt = `Tu es un scout sportif professionnel de haut niveau (UEFA Pro, NBA, World Rugby). 
Génère un rapport de scouting complet et professionnel en français pour ce joueur.

Données du joueur:
- Nom: ${nom}
- Âge: ${age} ans
- Sport: ${sport}
- Poste/Spécialité: ${poste}
- Niveau actuel: ${niveau}
- Score technique: ${tech}/10
- Score physique: ${phys}/10
- Intelligence de jeu: ${tact}/10
- Observations: ${obs || 'Aucune'}

Réponds UNIQUEMENT en JSON valide sans backticks ni markdown:
{
  "overall": <entier 1-100>,
  "verdict": "<phrase courte style scout, max 8 mots>",
  "potential": <entier 1-100>,
  "potentialLabel": "<ex: Élite nationale, Pro, Régional>",
  "scores": [
    {"label": "Technique", "score": <1-20>},
    {"label": "Physique", "score": <1-20>},
    {"label": "Tactique", "score": <1-20>},
    {"label": "Mental", "score": <1-20>},
    {"label": "Vitesse", "score": <1-20>},
    {"label": "Leadership", "score": <1-20>}
  ],
  "strengths": ["<point fort 1>", "<point fort 2>", "<point fort 3>"],
  "weaknesses": ["<axe amélioration 1>", "<axe amélioration 2>"],
  "profile": "<3 phrases narratives style rapport scout pro>",
  "development": "<2 phrases sur le plan de développement>",
  "comparison": "<nom d'un joueur professionnel réel comparable>",
  "comparisonNote": "<1 phrase qui explique la comparaison>"
}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) {
      const err = await response.text();
      return res.status(500).json({ error: 'Erreur IA', details: err });
    }

    const data = await response.json();
    const raw = data.content?.[0]?.text || '';
    const clean = raw.replace(/```json|```/g, '').trim();
    const report = JSON.parse(clean);
    return res.status(200).json({ success: true, report });

  } catch (error) {
    return res.status(500).json({ error: 'Erreur serveur', message: error.message });
  }
}
